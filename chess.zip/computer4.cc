#include "computer4.h"

Computer4::Computer4(Color c, Board *board): Player(c, board) {
    humanPlayer = false;
}

Computer4::~Computer4() {}

bool Computer4::makeMove(int fromX, int fromY, int toX, int toY){

}
